# Examples

This folder may contain small example datasets for testing the plugin.

Recommended future example structure:

```text
examples/
├── small_dem.tif
├── design_mask.gpkg
├── exclusions.gpkg
└── expected_outputs/